# desynced-mod-weak-bugs

![icon](Trilobyte.png?raw=true)

Changes:
- Bugs have one HP
- Bug buildings have one HP
- Bug attacks do zero damage

Notes:
- Only applies to bugs spawned after the mod is loaded
